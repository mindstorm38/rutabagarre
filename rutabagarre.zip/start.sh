#!/bin/bash
python src/main.py
